import tkinter as tk
from tkinter import messagebox
import random

# Board size and cell size
board_size = 8
cell_size = 80

# Chess piece initialization
initial_player_pieces = {
    "pawn": [(1, i) for i in range(board_size)],
    "rook": [(0, 0), (0, 7)],
    "knight": [(0, 1), (0, 6)],
    "bishop": [(0, 2), (0, 5)],
    "queen": [(0, 3)],
    "king": [(0, 4)]
}
initial_opponent_pieces = {
    "pawn": [(6, i) for i in range(board_size)],
    "rook": [(7, 0), (7, 7)],
    "knight": [(7, 1), (7, 6)],
    "bishop": [(7, 2), (7, 5)],
    "queen": [(7, 3)],
    "king": [(7, 4)]
}

# Helper functions for movement
def is_within_board(x, y):
    return 0 <= x < board_size and 0 <= y < board_size

def pawn_moves(x, y, direction=1, opponent_positions=[]):
    moves = []
    if is_within_board(x + direction, y) and (x + direction, y) not in opponent_positions:
        moves.append((x + direction, y))
    if (x == 1 and direction == 1) or (x == 6 and direction == -1):
        if is_within_board(x + 2 * direction, y) and (x + direction, y) not in opponent_positions:
            moves.append((x + 2 * direction, y))
    for dy in [-1, 1]:
        if is_within_board(x + direction, y + dy) and (x + direction, y + dy) in opponent_positions:
            moves.append((x + direction, y + dy))
    return moves

def knight_moves(x, y):
    moves = [(x + 2, y + 1), (x + 2, y - 1), (x - 2, y + 1), (x - 2, y - 1),
             (x + 1, y + 2), (x + 1, y - 2), (x - 1, y + 2), (x - 1, y - 2)]
    return [(i, j) for i, j in moves if is_within_board(i, j)]

def king_moves(x, y):
    moves = [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1),
             (x + 1, y + 1), (x + 1, y - 1), (x - 1, y + 1), (x - 1, y - 1)]
    return [(i, j) for i, j in moves if is_within_board(i, j)]

def bishop_moves(x, y):
    moves = []
    for dx in range(-7, 8):
        for dy in range(-7, 8):
            if abs(dx) == abs(dy) and dx != 0:
                if is_within_board(x + dx, y + dy):
                    moves.append((x + dx, y + dy))
    return moves

def rook_moves(x, y):
    moves = []
    for dx in range(-7, 8):
        if dx != 0 and is_within_board(x + dx, y):
            moves.append((x + dx, y))
        if is_within_board(x, y + dx):
            moves.append((x, y + dx))
    return moves

def queen_moves(x, y):
    return rook_moves(x, y) + bishop_moves(x, y)

def ai_move(piece, position):
    x, y = position
    if piece == "pawn":
        opponent_positions = [pos for positions in player_pieces.values() for pos in positions]
        return pawn_moves(x, y, direction=-1, opponent_positions=opponent_positions)
    elif piece == "knight":
        return knight_moves(x, y)
    elif piece == "king":
        return king_moves(x, y)
    elif piece == "bishop":
        return bishop_moves(x, y)
    elif piece == "rook":
        return rook_moves(x, y)
    elif piece == "queen":
        return queen_moves(x, y)
    return []

# GUI class
class ChessGUI:
    def __init__(self, root):
        self.root = root
        self.canvas = tk.Canvas(root, width=board_size * cell_size, height=board_size * cell_size)
        self.canvas.pack()
        self.reset_pieces()
        self.create_buttons()
        self.draw_board()
        self.draw_pieces()
        self.canvas.bind("<Button-1>", self.on_click)

    def reset_pieces(self):
        global player_pieces, opponent_pieces
        player_pieces = {key: value[:] for key, value in initial_player_pieces.items()}
        opponent_pieces = {key: value[:] for key, value in initial_opponent_pieces.items()}
        self.selected_piece = None
        self.selected_position = None

    def create_buttons(self):
        button_frame = tk.Frame(self.root)
        button_frame.pack()
        tk.Button(button_frame, text="Restart", command=self.restart_game).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Quit", command=self.quit_game).pack(side=tk.LEFT, padx=5)

    def draw_board(self):
        for i in range(board_size):
            for j in range(board_size):
                color = "Maroon" if (i + j) % 2 == 0 else "Light Coral"
                self.canvas.create_rectangle(
                    j * cell_size, i * cell_size, (j + 1) * cell_size, (i + 1) * cell_size, fill=color
                )

    def draw_pieces(self):
        self.canvas.delete("piece")
        for piece, positions in player_pieces.items():
            for pos in positions:
                self.draw_piece(piece, pos, "Beige")
        for piece, positions in opponent_pieces.items():
            for pos in positions:
                self.draw_piece(piece, pos, "black")

    def draw_piece(self, piece, position, color):
        x, y = position

        # Mapping piece names to Unicode chess symbols
        piece_symbols = {
            "pawn": "♙" if color == "Beige" else "♟",
            "rook": "♖" if color == "Beige" else "♜",
            "knight": "♘" if color == "Beige" else "♞",
            "bishop": "♗" if color == "Beige" else "♝",
            "queen": "♕" if color == "Beige" else "♛",
            "king": "♔" if color == "Beige" else "♚"
        }
        symbol = piece_symbols[piece]

        # Draw the symbol centered in the cell
        self.canvas.create_text(
            y * cell_size + cell_size // 2, x * cell_size + cell_size // 2,
            text=symbol, font=("Arial", cell_size // 2), fill=color, tags="piece"
        )

    def on_click(self, event):
        global player_pieces, opponent_pieces
        x, y = event.y // cell_size, event.x // cell_size
        clicked_piece = None

        for piece, positions in player_pieces.items():
            if (x, y) in positions:
                clicked_piece = piece
                break

        if self.selected_piece:
            valid_moves = self.get_valid_moves(self.selected_piece, self.selected_position)
            if (x, y) in valid_moves:
                player_pieces[self.selected_piece].remove(self.selected_position)
                player_pieces[self.selected_piece].append((x, y))

                for opp_piece, opp_positions in opponent_pieces.items():
                    if (x, y) in opp_positions:
                        opp_positions.remove((x, y))
                        if opp_piece == "king":
                            messagebox.showinfo("Game Over", "You win!")
                            self.root.quit()
                        break

                self.selected_piece = None
                self.ai_turn()
            else:
                self.selected_piece = None
        elif clicked_piece:
            self.selected_piece = clicked_piece
            self.selected_position = (x, y)

        self.draw_pieces()

    def get_valid_moves(self, piece, position):
        x, y = position
        if piece == "pawn":
            opponent_positions = [pos for positions in opponent_pieces.values() for pos in positions]
            return pawn_moves(x, y, direction=1, opponent_positions=opponent_positions)
        elif piece == "knight":
            return knight_moves(x, y)
        elif piece == "king":
            return king_moves(x, y)
        elif piece == "bishop":
            return bishop_moves(x, y)
        elif piece == "rook":
            return rook_moves(x, y)
        elif piece == "queen":
            return queen_moves(x, y)
        return []

    def ai_turn(self):
        for piece, positions in opponent_pieces.items():
            for position in positions:
                move = random.choice(ai_move(piece, position)) if ai_move(piece, position) else None
                if move:
                    positions.remove(position)
                    positions.append(move)
                    for player_piece, player_positions in player_pieces.items():
                        if move in player_positions:
                            player_positions.remove(move)
                            if player_piece == "king":
                                messagebox.showinfo("Game Over", "You lose!")
                                self.root.quit()
                            break
                    return

    def restart_game(self):
        self.reset_pieces()
        self.draw_board()
        self.draw_pieces()

    def quit_game(self):
        self.root.quit()

# Start the game
root = tk.Tk()
root.title("Chess Game")
app = ChessGUI(root)

root.mainloop()
